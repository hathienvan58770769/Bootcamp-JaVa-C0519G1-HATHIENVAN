let Rectangle = function(height, width) {
    this.height  = height;
    this.width = width;
    this.getAcreage = function(){
        return this.height * this.width;
    }
    this.getPerimeter = function(){
        return (this.height + this.width)*2;
    }
    
}
let getRandomHex = function() {
    return Math.floor(Math.random()*215);
}
let getRandomColor = function() {
    let black = getRandomHex();
    
    return "rgb(" + black +")";
}
function getRectangle() {
    let canvastxt = document.getElementById('myCanvas').getContext("2d");
    let color = getRandomColor();
    let rectangle = new Rectangle(100, 200);
    canvastxt.fillRect(200,100,rectangle.width, rectangle.height);
    canvastxt.fillStyle = color;
    canvastxt.fill();
    document.getElementById('getPerimeter').innerHTML = 'Chu vi hình chữ nhật: ' + rectangle.getPerimeter();
    document.getElementById('getAcreage').innerHTML = 'Diện tích hình chữ nhật: ' + rectangle.getAcreage();
    }