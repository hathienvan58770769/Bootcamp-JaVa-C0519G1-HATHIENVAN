export class Course{
    public id : number;
    public name : string;
    public description : string;
    public fee : number;
}