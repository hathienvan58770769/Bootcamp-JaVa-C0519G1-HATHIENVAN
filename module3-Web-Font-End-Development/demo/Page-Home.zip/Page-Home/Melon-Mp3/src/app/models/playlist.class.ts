export class Playlist{
    id:number;
    name_playlist: string;
    list_song:[string];
}