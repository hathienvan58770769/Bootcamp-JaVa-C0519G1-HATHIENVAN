export class Song{
    id : number;
    name_song : string;
    name_artist : string;
    description : string;
    label : string;
    fileMp3:string;
    avatar:string;
}